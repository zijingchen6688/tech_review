# Tech Review

Please enter your topics here: https://docs.google.com/spreadsheets/d/1rYlXm-46abhU4Lg7K2zrDE6VSl2uH_tNql1S7fd1UIM/edit?usp=sharing
Some sample topics have been provided here: https://docs.google.com/spreadsheets/d/1yeKm8hJbyRGhiUDvZv9-S3Zzu5hDtET-O6Yeci-VPOs/edit?usp=sharing

## Due: Nov 8, 2020 at 11:59 pm